----------=----------=----------

Piano Music Database
Press/Media Kit and Information about Piano Music Database
Last Updated: February 20, 2025

----------=----------=----------

--- Piano Music Database Facts ---

Name:
- Piano Music Database LLC

Tagline:
- Find the Perfect Piece

Description:
- Piano Music Database is a search engine and database of pedagogical piano repertoire. All music in our database is analyzed and categorized by level, elements, moods, styles, and more. You'll find music by living composers, the masters throughout history, as well as many under-represented composers.

How It Works:
- Our team of piano teachers analyze each piece in our collection using over 25 different data points like: pedagogical concepts, difficulty level, mood, style, and themes. Our powerful search engine gives users the ability to quickly search through our entire collection of music using these data points as search filters. The result is a robust tool that gives piano teachers an incredible amount of data about piano music and an easy way to track down the best music for their piano students.

History:
- The original idea for Piano Music Database came from the familiar struggles that we've all faced as piano teachers: to find interesting and technically appropriate music for our students. From this basic idea, came a simple spreadsheet, then a website, and now a fully fledged search engine. Today, Piano Music Database is managed by a small and dedicated team of developers, pianists, teachers, and designers.

Mission:
- Our mission is to provide piano teachers with the most accurate and detailed data about piano music available and to build tools that allow them to use that data to improve their teaching.

Website Links:
- Homepage: [PianoMusicDatabase.com](https://PianoMusicDatabase.com)
- Search: [PianoMusicDatabase.com/search](https://PianoMusicDatabase.com/search)

Primary Contact:
- Contact@PianoMusicDatabase.com

Founder/Owner:
- William Perry

Release Date:
- December 13, 2021

Development Starting Date:
- May 3, 2020

Development Location:
- Business Based in Cincinnati, Ohio, USA
- Work Performed is International Remote Work

Platform Information:
- Fast, responsive, and accessible "[Next.js](https://nextjs.org) with [Tailwind CSS](https://tailwindcss.com) in [TypeScript](https://typescriptlang.org)" PWA/website
- Robust database/API using [Strapi](https://strapi.io) with [TypeScript](https://typescriptlang.org) powered by a [PostgreSQL](https://postgresql.org) database
- Powerful search engine using [Typesense](https://typesense.org)
- Emails using [Brevo](https://brevo.com)
- Continuous integration and continuous delivery/deployment using [GitHub](https://github.com)
- Compatible with most desktop (PC/Mac/Linux) and mobile (iOS/Android/other) internet browsers

Target Audience:
- Piano Teachers and Piano Students

----------=----------=----------

--- Piano Music Database Branding ---

--- Piano Music Database Font ---
[Montserrat](https://github.com/JulietaUla/Montserrat) by [Julieta Ulanovsky](https://github.com/JulietaUla) (Copyright 2010-2021 Julieta Ulanovsky) (SIL Open Font License 1.1)

--- Piano Music Database Colors ---
"PMD Red"
	HEX: #7f1d1d
	RGB: 127, 29, 29
	CYMK: 0%, 77%, 77%, 50%
	HSV: 0°, 77%, 50%
	HSL: 0°, 63%, 31%
	TailwindCSS: red-900
	VarName: pmdRed
"White BG/Text"
	HEX: #ffffff
	RGB: 255, 255, 255
	CYMK: 0%, 0%, 0%, 0%
	HSV: 0°, 0%, 100%
	HSL: 0°, 0%, 100%
	TailwindCSS: white
	VarName: white
"Black BG/Text"
	HEX: #000000
	RGB: 0, 0, 0
	CYMK: 0%, 0%, 0%, 100%
	HSV: 0°, 0%, 0%
	HSL: 0°, 0%, 0%
	TailwindCSS: black
	VarName: black
"Bright Gray BG"
	HEX: #fafaf9
	RGB: 250, 250, 249
	CYMK: 0%, 0%, 0%, 2%
	HSV: 60°, 0%, 98%
	HSL: 60°, 9%, 98%
	TailwindCSS: stone-50
	VarName: pmdGrayBright
"Light Gray BG"
	HEX: #e7e5e4
	RGB: 231, 229, 228
	CYMK: 0%, 1%, 1%, 9%
	HSV: 20°, 1%, 91%
	HSL: 20°, 6%, 90%
	TailwindCSS: stone-200
	VarName: pmdGrayLight
"Gray BG"
    HEX: #a8a29e
    RGB: 168, 162, 158
    CYMK: 0%, 4%, 6%, 34%
    HSV: 24°, 6%, 66%
    HSL: 24°, 5%, 64%
    TailwindCSS: stone-400
	VarName: pmdGray
"Dark Gray BG"
	HEX: #262626
	RGB: 38, 38, 38
	CYMK: 0%, 0%, 0%, 85%
	HSV: 0°, 0%, 15%
	HSL: 0°, 0%, 15%
	TailwindCSS: neutral-800
	VarName: pmdGrayDark

----------=----------=----------

--- Connect to Piano Music Database on Social Media ---

Email:
- Contact@PianoMusicDatabase.com

Facebook:
- [/PianoMusicDatabase](https://facebook.com/PianoMusicDatabase)

Instagram:
- [@PianoMusicDatabase](https://instagram.com/PianoMusicDatabase)

Threads:
- [@PianoMusicDatabase](https://threads.net/PianoMusicDatabase)

Youtube:
- [@PianoMusicDatabase](https://youtube.com/@PianoMusicDatabase)

Reddit:
- [r/PianoMusicDatabase](https://reddit.com/r/PianoMusicDatabase)

LinkedIn:
- [/Piano-Music-Database](https://linkedin.com/company/Piano-Music-Database)

Discord Server:
- [/G8vEbn7ajF](https://discord.gg/G8vEbn7ajF)

----------=----------=----------